/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MessageManagerTest;

/**
 *
 * @author Shimi
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MessageManagerTest {
    private MessageManager seeded() {
        MessageManager m = new MessageManager();
        m.setTestData(
            new String[]{"1234567890","1234567891","1234567892","1234567893","1234567894"},
            new String[]{"Did you get the cake?","Where are you? You are late! I have asked you to be on time.",
                         "It is dinner time !","Ok, I am leaving without you.","Hi dinner time."},
            new String[]{"+27834557896","+27838884567","+27838884567","0838884567","+27838884567"},
            new String[]{"Sent","Stored","Disregarded","Sent","Stored"},
            new String[]{"H1","H2","H3","H4","H5"});
        return m;
    }

    @Test void sentMessagesArrayCorrectlyPopulated() {
        MessageManager m = seeded();
        assertEquals("Did you get the cake?", m.sentMessages[0]);
    }
    @Test void longestMessage() {
        assertEquals("Hi dinner time.", seeded().displayLongestMessage());
    }
    @Test void searchMessageID() {
        assertEquals("It is dinner time !", seeded().searchMessageID("1234567892"));
    }
    @Test void searchAll() {
        assertEquals(3, seeded().searchAll("+27838884567").split("\n").length);
    }
    @Test void deleteByHash() {
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
                     seeded().deleteByHash("H2"));
    }
    @Test void displayReport() {
        assertTrue(seeded().displayReport().contains("MessageHash: H1"));
    }
}