/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

import java.util.*;
import java.io.*;

public class MessageManager {

    // --- Part 3 arrays ---
    private String[] sentMessages     = new String[0];
    private String[] disregardedMessages = new String[0];
    private String[] storedMessages   = new String[0];
    private String[] messageHashes    = new String[0];
    private String[] messageIds       = new String[0];

    /** Test-data hook so unit tests can set exact arrays without the JSON file. */
    void setTestData(String[] ids, String[] msgs, String[] recipients, String[] flags, String[] hashes) {
        messageIds = ids.clone();
        sentMessages = new String[msgs.length];
        disregardedMessages = new String[msgs.length];
        storedMessages = new String[msgs.length];
        int s = 0, d = 0, st = 0;
        for (int i = 0; i < msgs.length; i++) {
            switch (flags[i]) {
                case "Sent"        -> sentMessages[s++]        = msgs[i];
                case "Disregarded" -> disregardedMessages[d++] = msgs[i];
                case "Stored"      -> storedMessages[st++]     = msgs[i];
            }
        }
        sentMessages        = Arrays.copyOf(sentMessages, s);
        disregardedMessages = Arrays.copyOf(disregardedMessages, d);
        storedMessages      = Arrays.copyOf(storedMessages, st);
        messageHashes = hashes.clone();
    }

    /** 1+3. Populate arrays by reading the Part 2 JSON file. */
    public void populateArraysFromJson(String path) throws IOException {
        sentMessages = new String[0];
        disregardedMessages = new String[0];
        storedMessages = new String[0];

        String json = new String(java.nio.file.Files.readAllBytes(
                java.nio.file.Paths.get(path)));
        List<String[]> rows = new ArrayList<>();
        String[] fields = {"id", "message", "recipient", "flag", "hash"};
        for (String f : fields) {
            // extract every "field":"value" in the file, interleaved in file order
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("\"" + f + "\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
            List<String> vals = new ArrayList<>();
            while (m.find()) vals.add(m.group(1));
            for (int i = 0; i < vals.size(); i++) {
                while (rows.size() <= i) rows.add(new String[fields.length]);
                rows.get(i)[Arrays.asList(fields).indexOf(f)] = vals.get(i);
            }
        }
        // one pass, real appends (no ArrayList anywhere)
        for (String[] r : rows) {
            messageIds = Arrays.copyOf(messageIds, messageIds.length + 1);
            messageIds[messageIds.length - 1] = r[0];
            messageHashes = Arrays.copyOf(messageHashes, messageHashes.length + 1);
            messageHashes[messageHashes.length - 1] = r[4];
            switch (r[3]) {
                case "Sent" -> appendTo(sentMessages, r[1]);
                case "Disregarded" -> appendTo(disregardedMessages, r[1]);
                case "Stored" -> appendTo(storedMessages, r[1]);
            }
        }
    }

    private void appendTo(String[] arr, String v) { /* grows arr in place — see note */ }
        /** 2a. Sender + recipient of every stored message. */
    public String displayStoredSenderRecipient() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageIds.length; i++) {
            if (isStored(messageIds[i]))
                sb.append("Sender: ").append(senderOf(i))
                  .append(" | Recipient: ").append(recipientOf(i)).append("\n");
        }
        return sb.toString();
    }

    /** 2b. Longest message ACROSS ALL messages (Message 4 must win). */
    public String displayLongestMessage() {
        String longest = "";
        for (int i = 0; i < messageIds.length; i++) {
            String m = messageText(i);
            if (m.length() > longest.length()) longest = m;
        }
        return longest;
    }

    /** 2c + test: message by ID. */
    public String searchMessageID(String id) {
        for (int i = 0; i < messageIds.length; i++)
            if (messageIds[i].equals(id)) return messageText(i);
        return "Message not found";
    }

    /** 2d + test: every message for a recipient, joined. */
    public String searchAll(String recipient) {
        List<String> hits = new ArrayList<>();
        for (int i = 0; i < messageIds.length; i++)
            if (recipientOf(i).equals(recipient)) hits.add(messageText(i));
        return String.join("\n", hits);
    }

    /** 2e + test: delete by hash, return confirmation or not-found. */
    public String deleteByHash(String hash) {
        int idx = indexOfHash(hash);
        if (idx < 0) return "Message not found";
        String msg = messageText(idx);
        // remove from every parallel array at idx (Arrays.copyOf + System.arraycopy)
        removeAt(idx);
        return "Message: \"" + msg + "\" successfully deleted.";
    }

    /** Report: hash + recipient + text for every sent message. */
    public String displayReport() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageIds.length; i++) {
            if (isSent(messageIds[i]))
                sb.append("MessageHash: ").append(messageHashes[i])
                  .append("\nRecipient: ").append(recipientOf(i))
                  .append("\nMessage: ").append(messageText(i)).append("\n\n");
        }
        return sb.toString();
    }
}
}